-- =============================================
-- Script: Create USER_STATES Table
-- Author: [Kareem]
-- Date: [19-May-2025]
-- Description: Drops and recreates the USER_STATES table.
-- =============================================

-- Drop the FEATURES table if it already exists

IF OBJECT_ID('dbo.USER_STATES', 'U') IS NOT NULL
    DROP TABLE dbo.USER_STATES;
GO


CREATE TABLE USER_STATES (
    USER_STATES_ID INT IDENTITY(1,1),
    USER_ID INT NOT NULL,
    SERVICE_STATE CHAR(2) NOT NULL,
    IN_ACTIVE_DATE DATETIME NULL,
    ACTIVE BIT NOT NULL,
    CREATED_ON DATETIME NOT NULL,
    CREATED_BY INT NOT NULL,
    MODIFIED_ON DATETIME NOT NULL,
    MODIFIED_BY INT NOT NULL
);
GO


